// abstract class NotificationService {
//   Future<void> initialize();
//   Future<void> showNotification(String title, String body, List<String> iconPaths, List<String> buttonLabels);
// }
