class AppString {
  // Storage keys
  static const String authBox = 'AuthBox';
  static const String appBox = 'AppBox';

  static const String accessToken = 'accessToken';
  static const String userId = 'userId';
  static const String languageCode = 'languageCode';
  static const String countryCode = 'countryCode';
  static const String firstOpen = 'firstOpen';
}
