export class NewChatroomDto {

}