export enum UserMood {
    VERYGOOD = 'VERYGOOD',
    GOOD = 'GOOD',
    NUETRAL = 'NUETRAL',
    BAD = 'BAD',
    VERYBAD = 'VERYBAD',
}