export enum UserType {
    ADULT = 'ADULT',
    STUDENT = 'STUDENT',
  }
  